2020 Connecticut precinct and election results shapefile.

## RDH Date retrieval
08/17/2021

## Sources
Election results from the Connecticut Secretary of State (https://portal.ct.gov/SOTS/Election-Services/Election-Results/Election-Results). 
Precinct shapefile from the U.S. Census Bureau's 2020 Redistricting Data Program.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G16PREDCli
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
AGR - Agriculture Commissioner
ATG - Attorney General
AUD - Auditor
COC - Corporation Commissioner
COU - City Council Member
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
INS - Insurance Commissioner
LAB - Labor Commissioner
LTG - Lieutenant Governor
PRE - President
PSC - Public Service Commissioner
RRC - Railroad Commissioner
SAC - State Appeals Court (in AL: Civil Appeals)
SCC - State Court of Criminal Appeals
SOS - Secretary of State
SSC - State Supreme Court
SPI - Superintendent of Public Instruction
TRE - Treasurer
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRERTRU - Donald J. Trump (Republican Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREGHAW - Howie Hawkins (Green Party of Delaware)
G20PREOWRI - Write-in Votes

## Processing Steps
District splits not reported separately were merged for Bethel 5, Bridgeport 129-3, 130-2, Durham 3, East Haven 3-3, Hartford 11, 12, 24, Naugatuck 3-3, New Britain 12, New Haven 9-2, 17, 21-1, Stamford 3, 5, 6-1, 8, 12, 20-1, 21, Torrington 6, 7, Waterbury 74-5.

The Stratford and Westport precincts were renumbered from municipal districts to state/federal districts.

The following additional modifications were made to match the 2020 precinct boundaries.

Ansonia: Adjust 1/2 to match shapefile
Avon: Adjust 1/3 to match street list
Berlin: Adjust 2/5 to match voter file
Bethel: Adjust 1/4 to match voter file
Bridgeport: Adjust 124-2/3/4, 126-1/2/5, 130-3/4 to match PDF
Colchester: Adjust 1/3, 2/4 to match street list
Coventry: Adjust 1/2 to match street list
Danbury: Align wards 4/5, 6/7 with PDF
Darien: Split 5/4-1, adjust 1/6 to match 2019 redistricting map
East Hartford: Adjust 1/2, 5/6 to match street list
East Haven: Add 1-3, 5-3 to match street list; Align 3, 3-3 with LD
East Windsor: Align 1, 1-2 with LD
Enfield: Adjust 258/458 to match PDF
Fairfield: Split 3-32/3-34 by LD; Adjust 8/9 to match PDF
Glastonbury: Adjust 4/5, 4/9, 7/9 to match PDF
Greenwich: Split 10/10-1 by LD; Adjust 1/2/3 to match PDF
Guilford: Adjust 1/3, 2/3 to match descriptions
Haddam: Adjust 1/2 to match street list
Hamden: Adjust 1/9, 5/6 to match PDF
Killingly: Merge 1/3/5, 2-1/4-1, 2-2/4-2
Ledyard: Adjust 1/2 to match street list
Litchfield: Adjust 2/4 to match voter file
Manchester: Adjust 3/5 to match street list
Middletown: Adjust 1/12 to match GIS
Milford: Align 117/119, 119-1/3 with LD and PDF
New Britain: Adjust 12/14 to match voter file
New Haven: Split 11-1/11-3 and align VTDs with voter file
New Milford: Align all VTDs with voter file
Newtown: Adjust 1/2 to match street list
Norwich: Adjust 4/5 to match voter file
Plainfield: Adjust 1/3, 2/4 to match voter file
Ridgefield: Adjust 1/2, 1/3 to match voter file
Rocky Hill: Adjust 2/3 to match voter file
Seymour: Adjust 1/3, 2/3 to match voter file
Shelton: Adjust 1/4, 2/3 to match PDF, voter file
Simsbury: Align 1/2 with 2017 redistricting
South Windsor: Adjust 3/5, 4/5 to match PDF
Southbury: Align all VTDs with shapefile, street list
Southington: Adjust 3/6, 5/8, 8/9 to match PDF
Stafford: Adjust 1/2 to match PDF
Stamford: Adjust 6/13 to match PDF
Stonington: Align all VTDs with shapefile
Stratford: Split 20-1/13, 80-1/21 by LD; Align VTDs with voter file
Vernon: Adjust 1/2, 2/3 to match PDF
Wallingford: Adjust 2/3, 2/4, 7/8 to match voter file
Waterbury: Align VTDs with PDF, street list, voter file
West Haven: Adjust 1/7, 4/5/6, 8/9/10 to match voter file
Weston: Adjust 1/2 to match voter file
Windham: Adjust 4/6 to match street list
Windsor: Adjust 1/3 to match street list
Wolcott: Adjust 1/2, 1/3 to match voter file