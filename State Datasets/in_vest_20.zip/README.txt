2020 Indiana precinct and election results shapefile.

## RDH Retrieval Date
09/13/2021

## Sources
Election results where available by precinct except Ohio County from the Indiana Secretary of State Election Division (https://enr.indianavoters.in.gov/site/index.html). 
Election results for the following counties from county canvass reports as processed by OpenElections: Benton, Carroll, Clark, Clay, Daviess, Dubois, Fayette, Fountain, Hancock, Jackson, Jasper, Jay, Jennings, LaPorte, Lawrence, Marshall, Montgomery, Morgan, Newton, Noble, Orange, Owen, Parke, Pulaski, Randolph, Scott, Spencer, Steuben, St. Joseph, Switzerland, Tipton, Warren, Warrick. 
Election results for the following counties directly from county canvass reports: Cass, Crawford, Dearborn, Floyd, Fulton, Greene, Hendricks, Ohio, Perry, Ripley, Starke, Tippecanoe, Vanderburgh, Vigo, Washington.
The canvass report from Ohio County differs from the Secretary of State precinct results for 3 precincts: Cass 7, Randolph 5, and Randolph 6. Consequently, the statewide totals differ from the final results reported on the SoS website as follows: Trump (R) +338, Biden (D) +82, Jorgensen (L) -331 for President; Rainwater (L) -66 for Governor; Rokita (R) -14 for Attorney General.
Precinct shapefile primarily from the U.S. Census Bureau's Redistricting Data Program. However, many counties featured outdated or inaccurate precinct boundaries usually related to changes in corporate boundaries. The correct 2020 precinct boundaries were identified using GIS maps from each county. As appropriate, precinct boundaries for the following counties were replaced using shapefiles from the Indiana Secretary of State Election Division or from the respective counties. Where necessary, boundaries were further edited to align with 2020 corporate boundaries as determined via county parcel records.
Adams, Allen, Bartholomew, Benton, Boone, Carroll, Cass, Clinton, Daviess, Dearborn, Decatur, Delaware, DeKalb, Elkhart, Fayette, Floyd, Fountain, Fulton, Grant, Greene, Hamilton, Huntington, Jackson, Jefferson, Johnson, Kosciusko, Lake, LaPorte, Lawrence, Marion, Monroe, Montgomery, Morgan, Perry, Porter, Posey, Rush, Scott, Shelby, Sullivan, Vanderburgh, Vermilion, Wayne, Wells.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G16PREDCli
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
AGR - Agriculture Commissioner
ATG - Attorney General
AUD - Auditor
COC - Corporation Commissioner
COU - City Council Member
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
INS - Insurance Commissioner
LAB - Labor Commissioner
LAN - Commissioner of Public Lands
LTG - Lieutenant Governor
PRE - President
PSC - Public Service Commissioner
RRC - Railroad Commissioner
SAC - State Appeals Court (in AL: Civil Appeals)
SCC - State Court of Criminal Appeals
SOS - Secretary of State
SSC - State Supreme Court
SPI - Superintendent of Public Instruction
TRE - Treasurer
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G20PRERTRU - Donald J. Trump (Republican Party)
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)

G20GOVRHOL - Eric Holcomb (Republican Party)
G20GOVDMYE - Woodrow (Woody) Myers (Democratic Party)
G20GOVLRAI - Donald G. Rainwater II (Libertarian Party)

G20ATGRROK - Todd Rokita (Republican Party)
G20ATGDWEI - Jonathan Weinzapfel (Democratic Party)