2020 Kentucky precinct and election results shapefile

## RDH Date retrieval
10/04/2022

## Sources
This file was retrieved from VEST at https://doi.org/10.7910/DVN/K7760H

Election results primarily from Kentucky State Board of Elections (https://elect.ky.gov/results/2020-2029/Pages/2020.aspx) Precinct shapefile from the U.S. Census Bureau's 2020 Redistricting Data Program.

Election results for the following counties were sourced in whole or in part from the respective county canvass reports: Bracken, Fayette, Harlan, Hart, Jefferson, Leslie, Logan, Powell, Spencer, Washington. Johnson, Knott, Magoffin, Menifee, and Rockcastle precinct results were obtained via the MIT Election Data and Science Lab (https://dataverse.harvard.edu/dataverse/2020_precincts).

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G16PREDCli
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
AGR - Agriculture Commissioner
ATG - Attorney General
AUD - Auditor
COC - Corporation Commissioner
COU - City Council Member
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
INS - Insurance Commissioner
LAB - Labor Commissioner
LAN - Commissioner of Public Lands
LTG - Lieutenant Governor
PRE - President
PSC - Public Service Commissioner
RRC - Railroad Commissioner
SAC - State Appeals Court (in AL: Civil Appeals)
SCC - State Court of Criminal Appeals
SOS - Secretary of State
SSC - State Supreme Court
SPI - Superintendent of Public Instruction
TRE - Treasurer
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G20PRERTRU - Donald J. Trump (Republican Party)
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREIWES - Kanye West (Independent)
G20PREIPIE - Brock Pierce (Independent)

G20USSRMCC - Mitch McConnell (Republican Party)
G20USSDMCG - Amy McGrath (Democratic Party)
G20USSLBAR - Brad Barron (Libertarian Party)

## Processing Steps
The 2020 general election was conducted with mail ballots and countywide vote centers due to the COVID-19 pandemic. Therefore, most counties reported results by vote center or as a countywide summary. Only 16 counties reported full or partial results by precinct. Another 11 counties reported results based on ballot styles such that some reporting units are distinguishable below the county level.

Countywide votes were distributed to precincts or reporting units in Clay, Edmonson, Grayson, Lyon, McLean, Rowan, Todd. These were distributed by candidate to reporting units based on their share of the precinct-level or district-level reported vote with an adjustment for voter turnout by party.

For the ky_2020 shapefile precincts have been merged and labeled to match the smallest identifiable units by which election results were reported by the respective counties. 

For the ky_2020_vtd_estimates shapefile the 2020 election results have been further apportioned to individual precincts based on the vote from the 2016 election results for President and for US Senate. The 2016 election results were adjusted where necessary to account for changes in precinct boundaries and modified to account for the change in the number of registered voters by precinct between November 2016 and November 2020. Votes for each candidate on the 2020 ballot were then distributed from 2020 reporting units to the precincts that comprise those reporting units based on the VR adjusted share of the 2016 vote from each precinct that was cast for that party's candidate or for the most ideologically similar candidate.