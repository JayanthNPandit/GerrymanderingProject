2020 Minnesota precinct and election results shapefile.

## RDH Date retrieval
04/07/2021

## Sources

Election results from Minnesota Secretary of State (https://www.sos.state.mn.us/elections-voting/election-results/2020/2020-general-election-results/). 
Precinct shapefile from Minnesota Geospatial Commons (https://gisdata.mn.gov/dataset/bdry-votingdistricts).

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G20PRERTRU
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes

GOV - Governor
PRE - President
PSC - Public Service Commissioner
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.


## Fields

G20PREDBID - Joseph R. Biden (Democratic-Farmer-Labor Party)
G20PRERTRU - Donald J. Trump (Republican Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREGHAW - Howie Hawkins (Green Party)
G20PREAFUE - Roque "Rocky" De La Fuente (Independence-Alliance Party)
G20PREPLAR - Gloria La Riva (Socialism and Liberation Party)
G20PRESKEN - Alyson Kennedy (Socialist Workers Party)
G20PREIWES - Kanye West (Independent)
G20PREIPIE - Brock Pierce (Independent)
G20PREOWRI - Write-in Votes

G20USSDSMI - Tina Smith (Democratic-Farmer-Labor Party)
G20USSRLEW - Jason Lewis (Republican Party)
G20USSMOCO - Kevin O'Connor (Legal Marijuana Now Party)
G20USSCSTE - Oliver Steinberg (Grassroots - Legalize Cannabis Party)
G20USSOWRI - Write-in Votes