2020 New Hampshire precinct and election results shapefile.

## RDH Date retrieval
04/07/2021

## Sources

Election results from New Hampshire Secretary of State (https://sos.nh.gov/elections/elections/election-results/2020/general-election/). 
Precinct shapefile from the U.S. Census Bureau's 2020 Redistricting Data Program final release.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G20PRERTRU
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes

GOV - Governor
PRE - President
PSC - Public Service Commissioner
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.


## Fields

G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRERTRU - Donald J. Trump (Republican Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)

G20USSDSHA - Jeanne Shaheen (Democratic Party)
G20USSRMES - Corky Messner (Republican Party)
G20USSLODO - Justin O'Donnell (Libertarian Party)
G20USSOWRI - Write-in Votes

G20GOVDFEL - Dan Feltes (Democratic Party)
G20GOVRSUN - Chris Sununu (Republican Party)
G20GOVLPER - Darryl W. Perry (Libertarian Party)
G20GOVOWRI - Write-in Votes

## Processing Steps

The Census VTD shapefile includes wards for the Town of Berlin and the Town of Derry that are only used for municipal elections. These were merged to match the statewide election returns.