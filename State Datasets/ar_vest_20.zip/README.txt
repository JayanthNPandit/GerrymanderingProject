2020 Arkansas precinct and election results shapefile.

## RDH Date retrieval
08/03/2021

## Sources
Election results from Arkansas Secretary of State (https://www.sos.arkansas.gov/elections/research/election-results)

Precinct shapefile from the Arkansas GIS Office (http://gis.arkansas.gov/product/election-precincts/)

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G20PRERTRU
The first character is G for a general election, C for recount results, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
AGR - Agriculture Commissioner
ATG - Attorney General
AUD - Auditor
COC - Corporation Commissioner
COU - City Council Member
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
INS - Insurance Commissioner
LAB - Labor Commissioner
LTG - Lieutenant Governor
PRE - President
PSC - Public Service Commissioner
RRC - Railroad Commissioner
SAC - State Appeals Court (in AL: Civil Appeals)
SCC - State Court of Criminal Appeals
SOS - Secretary of State
SSC - State Supreme Court
SPI - Superintendent of Public Instruction
TRE - Treasurer
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.

## Fields
G20PRERTRU - Donald J. Trump (Republican Party)
G20PREDBID - Joseph R. Biden (Democratic Party)
G20PRELJOR - Jo Jorgensen (Libertarian Party)
G20PREGHAW - Howie Hawkins (Green Party)
G20PRECBLA - Don Blankenship (Constitution Party)
G20PREACAR - Brian Carroll (American Solidarity Party)
G20PREOMYE - John Richard Myers (Life and Liberty Party)
G20PRESLAR - Gloria La Riva (Socialism and Liberation Party)
G20PREIWES - Kanye West (Independent)
G20PREICOL - Phil Collins (Independent)
G20PREIPIE - Brock Pierce (Independent)
G20PREIGAM - C.L. Gammon (Independent)
G20PREIFUE - Roque "Rocky" De La Fuente (Independent)

G20USSRCOT - Tom Cotton (Republican Party)
G20USSDHAR - Ricky Dale Harrington Jr. (Libertarian Party)

## Processing Steps
Greene County was consolidated from 24 townships to 6 townships by court order in late 2019. Due to the proximity of the 2020 elections the results were reported by ballot type rather than by precincts based on the prior township map. The associated precinct parts were identified using the voter statistics report provided by the county. The relevant splits involve the state house districts, a Justice of the Peace district, and two school districts. Note also that in the general election results from the AR Secretary of State one of the reporting units in the new Bagwell Lake township is mislabeled as Crowley Ridge 3.

Precinct merges were made in the following counties to match county reporting units: Carroll, Crittenden, Dallas, Hot Spring, Howard, Independence, Mississippi, Monroe, Nevada, Phillips, Poinsett, St. Francis.

The following additional revisions were made to match the 2020 precinct boundaries.

Boone: Add precinct splits with municipal and district boundaries on county map
Greene: Align Paragould city wards with city PDF
Izard: Split Sage in Melbourne 4 and Oxford in Brockwell with township shapefile
Nevada: Split West Rural by township
Ouachita: Split 11/19 with township and state house district shapefiles
Phillips: Add Helena-West Helena wards from city redistricting map
Prairie: Split White River Country with school zone shapefile
Sebastian: Split 9-2A and 9-2C by Greenwood city ward
St. Francis: Align Forrest City wards with city PDF and municipal code